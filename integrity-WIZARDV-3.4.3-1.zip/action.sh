echo "we are updating your device's spoofed apps and adding them to target.txt, and checking your current setup to automatically fix what we can. please wait!"

#!/bin/sh


su -c rm -r /data/adb/modules/playintegrityfix
su -c rm -r /data/adb/modules/playintegrityfork
su -c rm -r /data/adb/modules/playcurl
su -c rm -r /data/adb/modules/sensitive_props
su -c rm -r /data/adb/modules/integrity-WIZARD
su -c rm -r /data/adb/modules/FrameworkPatcherGo

# Test
su -c rm /data/adb/tricky_store/global_mode
# Create or overwrite the target.txt file
su -c > /data/adb/tricky_store/target.txt

# Use to list all packages and process the output directly to target.txt
su -c pm list packages | awk -F: '{print $2}' > /data/adb/tricky_store/target.txt

su -c sleep 2 | echo "loading file please wait..."
 
su -c sed -i 's/$/!/g' /data/adb/tricky_store/target.txt

echo "target.txt updated!!! all apps have been successfully updated and spoofed! this tab will now automatically close in 10 seconds."

su -c killall com.google.android.gms

sleep 10




# Temporarily stopped due to server need. This is torture for most people.

#if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
#  rm "/data/adb/tricky_store/keybox.xml"
#fi
#random_keybox=$(find "/data/adb/modules/tricky_store/@MRootSu/@MRootSu/" -type f -name "*.xml" | shuf -n 1)
#if [ -z "$random_keybox" ]; then
#    exit 1
#fi
#cp "$random_keybox" "/data/adb/tricky_store/keybox.xml" 

#su -c killall com.google.android.gms
#su -c killall com.google.android.gms.unstable