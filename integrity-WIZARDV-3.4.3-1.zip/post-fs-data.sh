MODDIR=${0%/*}

chmod 000 /proc/bootconfig
chmod 000 /proc/bootinfo
chmod 000 /proc/keys
chmod 000 /proc/modules
chmod 000 /proc/kallsyms
if magisk --denylist status; then
    magisk --denylist rm com.google.android.gms
fi

resetprop_if_diff() {
    local NAME="$1"
    local EXPECTED="$2"
    local CURRENT="$(resetprop "$NAME")"
    
    [ -z "$CURRENT" ] || [ "$CURRENT" = "$EXPECTED" ] || resetprop -n "$NAME" "$EXPECTED"
}

# RootBeer, Microsoft
resetprop_if_diff ro.build.tags release-keys

# Samsung
resetprop_if_diff ro.boot.warranty_bit 0
resetprop_if_diff ro.vendor.boot.warranty_bit 0
resetprop_if_diff ro.vendor.warranty_bit 0
resetprop_if_diff ro.warranty_bit 0

# OnePlus
resetprop_if_diff ro.is_ever_orange 0

# Other
resetprop_if_diff ro.build.type user
resetprop_if_diff ro.debuggable 0
resetprop_if_diff ro.secure 1

BOOT_HASH_FILE="/data/adb/boot.hash"
if [ -s "$BOOT_HASH_FILE" ]; then
    resetprop -v -n ro.boot.vbmeta.digest "$(tr '[:upper:]' '[:lower:]' <"$BOOT_HASH_FILE")"
fi

# Cleanup and replacements (avoiding duplicates with service.sh)
for prop in $(getprop | grep -E "aosp_|test-keys"); do # Removed "userdebug" as it's handled in service.sh
    replace_value_resetprop "$prop" "aosp_" ""
    replace_value_resetprop "$prop" "test-keys" "release-keys"
done

# Process prefixes (optimized to avoid redundant checks)
for prefix in system vendor system_ext product oem odm vendor_dlkm odm_dlkm bootimage; do
    # Check and reset properties only once per prefix
    check_resetprop "ro.${prefix}.build.tags" release-keys
    check_resetprop "ro.${prefix}.build.type" user

    # Replace values in all relevant properties
    for prop in ro.${prefix}.build.{description,fingerprint} ro.product.${prefix}.name; do
        replace_value_resetprop "$prop" "aosp_" ""
    done

    # Hmmm
    # check_resetprop ro.${prefix}.build.date.utc $(date +"%s")
done

# check_resetprop ro.build.date.utc $(date +"%s")
# check_resetprop ro.build.version.security_patch $(date +2023-%m-%d)
# check_resetprop ro.vendor.build.security_patch $(date +2023-%m-%d)

# End Play Integrity Script ⭐

# Start BuiltIn BusyBox Script ⭐
MODDIR=${0%/*}


# Log Magisk version and magisk --path
magisk -c
magisk --path

# Clean-up old stuff
rm -rf "$MODDIR/system"

# Choose XBIN or BIN path
SDIR=/system/xbin
if [ ! -d $SDIR ]
then
  SDIR=/system/bin
fi
BBDIR=$MODDIR$SDIR
mkdir -p $BBDIR
cd $BBDIR
pwd

# ToyBox-Ext module path
TBDIR="/data/adb/modules/ToyBox-Ext/$SDIR"

# Check for local busybox binary
BB=busybox
BBBIN=$MODDIR/$BB
if [ -f $BBBIN ]
then
  chmod 755 $BBBIN
  if [ $($BBBIN --list | wc -l) -ge 128 ] && [ ! -z "$($BBBIN | head -n 1 | grep -i $BB)" ]
  then
    chcon u:object_r:system_file:s0 $BBBIN
    Applets=$BB$'\n'$($BBBIN --list)
  else
    rm -f $BBBIN
  fi
fi

# Otherwise use Magisk built-in busybox binary
if [ ! -x $BBBIN ]
then
  BBBIN=/data/adb/magisk/$BB
  $BBBIN --list | wc -l
  Applets=$BB$'\n'$($BBBIN --list)
fi

# Create local symlinks for BusyBox applets
for Applet in $Applets
do
  if [ ! -x $SDIR/$Applet ]
  then
    # Create symlink
    ln -s $BBBIN $Applet

    # Remove local symlink for ToyBox applet (prefer BusyBox)
    Target=$TBDIR/$Applet
    if [ -h $Target ]
    then
      rm -f $Target
    fi
  fi
done
chmod 755 *
chcon u:object_r:system_file:s0 *
