DEBUG=false

MODDIR=${0%/*}

cd $MODDIR

(
while [ true ]; do
  ./daemon
  if [ $? -ne 0 ]; then
    exit 1
  fi
  # ensure keystore initialized
  sleep 2
done
) &


# SELinux


#!/system/bin/busybox sh
resetprop_if_diff() {
    local NAME="$1"
    local EXPECTED="$2"
    local CURRENT="$(resetprop "$NAME")"
    
    [ -z "$CURRENT" ] || [ "$CURRENT" = "$EXPECTED" ] || resetprop -n "$NAME" "$EXPECTED"
}

resetprop_if_match() {
    local NAME="$1"
    local CONTAINS="$2"
    local VALUE="$3"
    
    [[ "$(resetprop "$NAME")" = *"$CONTAINS"* ]] && resetprop -n "$NAME" "$VALUE"
}

# Late props which must be set after boot_completed
{
    until [[ "$(getprop sys.boot_completed)" == "1" ]]; do
        sleep 1
    done
    
    # SafetyNet/Play Integrity | Avoid breaking Realme fingerprint scanners
    resetprop_if_diff ro.boot.flash.locked 1
    
    # SafetyNet/Play Integrity | Avoid breaking Oppo fingerprint scanners
    resetprop_if_diff ro.boot.vbmeta.device_state locked
    
    # SafetyNet/Play Integrity | Avoid breaking OnePlus display modes/fingerprint scanners
    resetprop_if_diff vendor.boot.verifiedbootstate green
    
    # SafetyNet/Play Integrity | Avoid breaking OnePlus display modes/fingerprint scanners on OOS 12
    resetprop_if_diff ro.boot.verifiedbootstate green
    resetprop_if_diff ro.boot.veritymode enforcing
    resetprop_if_diff vendor.boot.vbmeta.device_state locked

    # Custom ROMs support
    resetprop_if_diff persist.sys.pixelprops.pi false
}&
MODPATH="${0%/*}"     # Get the directory where the script is located
. "$MODPATH"/utils.sh # Load utils

# Wait for boot completion
while [ "$(getprop sys.boot_completed)" != 1 ]; do sleep 5; done

# Wait for the device to decrypt (if it's encrypted) when phone is unlocked once.
until [ -d "/sdcard/Android" ]; do sleep 10; done

# Props

# Fix display properties to remove custom ROM references
replace_value_resetprop ro.build.flavor "lineage_" ""
replace_value_resetprop ro.build.flavor "userdebug" "user"
replace_value_resetprop ro.build.display.id "lineage_" ""
replace_value_resetprop ro.build.display.id "userdebug" "user"
replace_value_resetprop ro.build.display.id "dev-keys" "release-keys"
replace_value_resetprop vendor.camera.aux.packagelist "lineageos." ""
replace_value_resetprop ro.build.version.incremental "eng." ""

# Periodically delete LineageOS and EvolutionX props
while true; do
    hexpatch_deleteprop "lineage"
    hexpatch_deleteprop "evolution"
    hexpatch_deleteprop "crdroid"
    hexpatch_deleteprop "crDroid"
    hexpatch_deleteprop "aospa"
    hexpatch_deleteprop "LSPosed"
    hexpatch_deleteprop "aicp"
    hexpatch_deleteprop "arter97"
    hexpatch_deleteprop "blu_spark"
    hexpatch_deleteprop "cyanogenmod"
    hexpatch_deleteprop "deathly"
    hexpatch_deleteprop "elementalx"
    hexpatch_deleteprop "elite"
    hexpatch_deleteprop "franco"
    hexpatch_deleteprop "hadeskernel"
    hexpatch_deleteprop "morokernel"
    hexpatch_deleteprop "noble"
    hexpatch_deleteprop "optimus"
    hexpatch_deleteprop "slimroms"
    hexpatch_deleteprop "sultan"
    hexpatch_deleteprop "aokp"
    hexpatch_deleteprop "bharos"
    hexpatch_deleteprop "calyxos"
    hexpatch_deleteprop "calyxOS"
    hexpatch_deleteprop "divestos"
    hexpatch_deleteprop "emteria.os"
    hexpatch_deleteprop "grapheneos"
    hexpatch_deleteprop "indus"
    hexpatch_deleteprop "iodéos"
    hexpatch_deleteprop "kali"
    hexpatch_deleteprop "nethunter"
    hexpatch_deleteprop "omnirom"
    hexpatch_deleteprop "paranoid"
    hexpatch_deleteprop "replicant"
    hexpatch_deleteprop "resurrection"
    hexpatch_deleteprop "remix"
    hexpatch_deleteprop "pixelexperience"
    hexpatch_deleteprop "shift"
    hexpatch_deleteprop "volla"
    hexpatch_deleteprop "icosa"
    hexpatch_deleteprop "kirisakura"
    hexpatch_deleteprop "infinity"
    hexpatch_deleteprop "Infinity"
    # add more...

    sleep 900 # Sleep for 15 minutes
done &        # Run the loop in the background

# Realme fingerprint fix
check_resetprop ro.boot.flash.locked 1
check_resetprop ro.boot.realmebootstate green
check_resetprop ro.boot.realme.lockstate 1

# Oppo fingerprint fix
check_resetprop ro.boot.vbmeta.device_state locked
check_resetprop vendor.boot.vbmeta.device_state locked

# OnePlus display/fingerprint fix
check_resetprop vendor.boot.verifiedbootstate green
check_resetprop ro.is_ever_orange 0

# OnePlus/Oppo display fingerprint fix on OOS/ColorOS 12+
check_resetprop ro.boot.verifiedbootstate green
check_resetprop ro.boot.veritymode enforcing

replace_value_resetprop ro.${prefix}.build.version.incremental "eng." ""
done

[ "$(resetprop -v ro.product.first_api_level)" -ge 33 ] && resetprop -v -n ro.product.first_api_level 32
done
# Fix Partition Check Failed using verifiedBootHash
# resetprop -v -n ro.boot.vbmeta.digest $(echo "" | tr '[:upper:]' '[:lower:]' | tr 'o' '0') # Preferably a module/applet could get the value.

# Samsung warranty bit fix
for prop in ro.boot.warranty_bit ro.warranty_bit ro.vendor.boot.warranty_bit ro.vendor.warranty_bit; do
    check_resetprop "$prop" 0
done

# General adjustments

# Process prefixes for build properties
for prefix in bootimage odm odm_dlkm oem product system system_ext vendor vendor_dlkm; do
    check_resetprop ro.${prefix}.build.type user
    check_resetprop ro.${prefix}.keys release-keys
    check_resetprop ro.${prefix}.build.tags release-keys

    # Remove engineering ROM
    replace_value_resetprop ro.${prefix}.build.version.incremental "eng." ""
done

# SafetyNet/banking app compatibility
check_resetprop net.tethering.noprovisioning true
check_resetprop sys.oem_unlock_allowed 0
check_resetprop ro.oem_unlock_supported 0

# Init.rc adjustment
check_resetprop init.svc.flash_recovery stopped

# Fake encryption status
check_resetprop ro.crypto.state encrypted

# Secure boot and device lock settings
check_resetprop ro.secureboot.devicelock 1
check_resetprop ro.secure 1
check_resetprop ro.secureboot.lockstate locked

# Disable debugging and adb over network
check_resetprop ro.debuggable 0
check_resetprop ro.adb.secure 0

# Maybe reset properties based on conditions (recovery boot mode)
for prop in ro.bootmode ro.boot.bootmode ro.boot.mode vendor.bootmode vendor.boot.bootmode vendor.boot.mode; do
    maybe_resetprop "$prop" recovery unknown
done

check_reset_prop() {
  local NAME=$1
  local EXPECTED=$2
  local VALUE=$(resetprop $NAME)
  [ -z $VALUE ] || [ $VALUE = $EXPECTED ] || resetprop $NAME $EXPECTED
}

contains_reset_prop() {
  local NAME=$1
  local CONTAINS=$2
  local NEWVAL=$3
  [[ "$(resetprop $NAME)" = *"$CONTAINS"* ]] && resetprop $NAME $NEWVAL
}

resetprop -w sys.boot_completed 0

check_reset_prop "gsm.operator.iso-country" "cn,"
check_reset_prop "ro.boot.hwc" "CN"
check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "ro.warranty_bit" "0"
check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.adb.secure" "1"
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"
check_reset_prop "ro.vendor.boot.warranty_bit" "0"
check_reset_prop "ro.vendor.warranty_bit" "0"
check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
check_reset_prop "vendor.boot.verifiedbootstate" "green"
check_reset_prop "sys.oem_unlock_allowed" "0"

# MIUI specific
check_reset_prop "ro.secureboot.lockstate" "locked"

# Realme specific
check_reset_prop "ro.boot.realmebootstate" "green"
check_reset_prop "ro.boot.realme.lockstate" "1"

# Hide that we booted from recovery when magisk is in recovery mode
contains_reset_prop "ro.bootmode" "recovery" "unknown"
contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"

}&
fi

# @MRootSu cn rom
resetprop ro.boot.hwc CN
resetprop ro.boot.hwlevel MP
resetprop gsm.sim.operator.iso-country cn
resetprop gsm.operator.iso-country cn

# Remove magisk 32bit support @MRootSu
if [ -d "/data/adb/magisk/" ]; then
    rm -f /debug_ramdisk/magisk32
rm -f /data/adb/magisk/magisk32
find /data/adb/modules -type f -name "armeabi-v7a.so" ! -path "/data/adb/modules/zygisk_shamiko/zygisk/armeabi-v7a.so" -delete
rm -f /data/adb/modules/*/zygisk/x86_64.so
rm -f /data/adb/modules/*/zygisk/x86.so
fi


    # Disable LSPosed logs @MRootSu
    resetprop persist.log.tag.LSPosed S
    resetprop persist.log.tag.LSPosed-Bridge S
fi

    # Delete LSPosed props
    resetprop -w sys.boot_completed 0
    resetprop -d persist.log.tag.LSPosed
    resetprop -d persist.log.tag.LSPosed-Bridge
fi

# Credit @MRootSu cn rom
resetprop -w sys.boot_completed 0
resetprop -n persist.radio.skhwc_matchres "MATCH"
resetprop -n gsm.operator.iso-country "cn"
resetprop -n ro.boot.hwlevel "MP"
resetprop -n ro.boot.hwc "CN"
